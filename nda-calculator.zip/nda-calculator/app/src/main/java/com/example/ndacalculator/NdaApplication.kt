package com.example.ndacalculator

import android.app.Application

class NdaApplication : Application()